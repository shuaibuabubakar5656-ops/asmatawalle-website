const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('../db');
const { signToken, requireAuth } = require('../middleware/auth');

const router = express.Router();

/** POST /api/auth/register  – student signup */
router.post('/register', (req, res) => {
  try {
    const { name, email, phone, password } = req.body || {};
    if (!name || !email || !phone || !password || password.length < 6) {
      return res.status(400).json({ ok: false, message: 'Please fill all fields. Password min 6 characters.' });
    }
    const cleanEmail = String(email).trim().toLowerCase();

    const exists = db.prepare('SELECT id FROM users WHERE email = ?').get(cleanEmail);
    if (exists) {
      return res.status(409).json({ ok: false, message: 'An account with this email already exists. Please login.' });
    }

    const hash = bcrypt.hashSync(password, 10);
    const info = db.prepare(
      `INSERT INTO users (name, email, phone, password_hash, role) VALUES (?, ?, ?, ?, 'student')`
    ).run(name.trim(), cleanEmail, String(phone).trim(), hash);

    const user = {
      id: info.lastInsertRowid,
      name: name.trim(),
      email: cleanEmail,
      phone: String(phone).trim(),
      role: 'student'
    };
    const token = signToken(user);
    res.status(201).json({ ok: true, token, user });
  } catch (e) {
    console.error(e);
    res.status(500).json({ ok: false, message: 'Server error during registration' });
  }
});

/** POST /api/auth/login */
router.post('/login', (req, res) => {
  try {
    const { email, password } = req.body || {};
    if (!email || !password) {
      return res.status(400).json({ ok: false, message: 'Email and password required' });
    }
    const cleanEmail = String(email).trim().toLowerCase();
    const row = db.prepare('SELECT * FROM users WHERE email = ?').get(cleanEmail);
    if (!row || !bcrypt.compareSync(password, row.password_hash)) {
      return res.status(401).json({ ok: false, message: 'Invalid email or password' });
    }
    const user = { id: row.id, name: row.name, email: row.email, phone: row.phone, role: row.role };
    const token = signToken(user);
    res.json({ ok: true, token, user });
  } catch (e) {
    console.error(e);
    res.status(500).json({ ok: false, message: 'Server error during login' });
  }
});

/** GET /api/auth/me  – current user */
router.get('/me', requireAuth, (req, res) => {
  const row = db.prepare('SELECT id, name, email, phone, role, created_at FROM users WHERE id = ?').get(req.user.id);
  if (!row) return res.status(404).json({ ok: false, message: 'User not found' });
  res.json({ ok: true, user: row });
});

module.exports = router;
